---
name: financing-product-advisor-dual-view
description: "advise on the most suitable business lending product or product mix from financial information such as annual accounts, trial balance, interim figures, bank transactions, liquidity forecasts, management information, and optional output from geenbank-kredietworkflow. use when chatgpt must translate financing purpose, repayment capacity, collateral support, evidence quality, and structure feasibility into two aligned outputs: entrepreneur-readable guidance with cta and to-do lists, plus a structured partner-facing recommendation in json."
---

# Financing Product Advisor Dual View

Use this skill to assess a business financing case and produce one analysis with two aligned outputs:
- an entrepreneur view in plain language
- a partner view for submission shaping and product selection

## Inputs
Accept any combination of:
- annual accounts
- trial balance
- interim figures
- bank transactions
- liquidity forecasts
- management information
- optional output from `geenbank-kredietworkflow`

Treat `geenbank-kredietworkflow` output as enrichment, not as sole authority.

## Workflow
Follow this sequence:
1. Normalize the case inputs and identify missing critical evidence.
2. Determine the financing purpose and split mixed needs into purpose components where relevant.
3. Assess repayment capacity using cash flow, solvency, dscr, ebitda, and related indicators when available.
4. Assess collateral support and bank-transaction evidence.
5. Build a shortlist from the relevant product families instead of forcing a full-universe comparison.
6. Recommend the best single product and, if justified, the best product mix.
7. Build an indicative structure.
8. Determine the entrepreneur cta status.
9. Produce both the entrepreneur view and partner view.
10. Return readable chat output and structured json.

## Decision discipline
Treat these as leading decision criteria:
- financing purpose
- repayment capacity
- collateral quality
- evidence quality
- structure feasibility

Treat these as relevant but not leading:
- amount requested
- urgency
- company age
- sector
- seasonality

Do not let a non-leading factor override a strong financing fit unless it creates a real feasibility issue.

## Product universe
Only consider relevant products from this set:
- revolving credit or working-capital line
- business term loan
- commercial real-estate finance
- equipment lease
- financial lease
- factoring
- receivables finance
- bridge financing
- subordinated loan
- sale-and-lease-back

Build a shortlist based on purpose, evidence, collateral, and structure feasibility.

## Recommendation rules
Always determine:
- best product
- best alternative
- best justified product mix if a mix is materially better than a single product
- indicative tenor, repayment logic, collateral logic, and key conditions when they can be inferred responsibly

If information is incomplete, do not pretend certainty. Downgrade confidence, identify missing evidence, and adjust the entrepreneur cta accordingly.

## Entrepreneur view
The entrepreneur view must be in clear Dutch and must include:
- short outcome summary
- strongest points in the case
- weakest points or lender concerns
- financeability score from 1 to 10
- submission readiness score from 1 to 10
- one cta status
- minimum to-do list
- optimal to-do list

Use these cta statuses only:
- `ready_to_submit`
- `ready_to_submit_with_evidence_boosters`
- `not_ready_missing_evidence`
- `not_ready_restructure_case`
- `not_financeable_with_external_debt_now`

Meaning of cta statuses:
- `ready_to_submit`: case is sufficiently evidenced and appears externally financeable in current form.
- `ready_to_submit_with_evidence_boosters`: case is submittable now, but additional evidence would improve placement quality or success odds.
- `not_ready_missing_evidence`: case may be financeable, but current evidence is too incomplete for responsible submission.
- `not_ready_restructure_case`: current form is weak, but a better amount, tenor, product, collateral package, or product mix may create a workable case.
- `not_financeable_with_external_debt_now`: current case is not suitable for external debt in a responsible structure.

For to-do lists, always separate:
- minimum required next steps
- optimal strengthening steps

## Partner view
The partner view must remain practical and structured. Include:
- recommended product
- alternative product
- recommended product mix if applicable
- rationale
- key risks
- evidence gaps
- indicative structure
- recommendation status using `strong`, `provisional`, or `weak`
- product scores for shortlisted products:
  - `product_fit_score`
  - `evidence_strength_score`
  - `structurability_score`

## Output requirements
### Chat output
Default structure:
1. ondernemer samenvatting
2. sterke punten
3. aandachtspunten vanuit financier
4. scores
5. cta
6. to-do minimum
7. to-do optimaal
8. partneradvies samenvatting

### JSON output
Always return a top-level JSON object with this shape:

```json
{
  "entrepreneur_view": {
    "summary": "",
    "strengths": [],
    "weaknesses": [],
    "financeability_score": 0,
    "submission_readiness_score": 0,
    "cta_status": "",
    "todo_minimum": [],
    "todo_optimal": []
  },
  "partner_view": {
    "recommended_product": "",
    "alternative_product": "",
    "recommended_product_mix": [],
    "recommendation_status": "",
    "rationale": [],
    "key_risks": [],
    "evidence_gaps": [],
    "indicative_structure": {
      "amount": null,
      "tenor_months": null,
      "repayment_logic": "",
      "collateral_logic": "",
      "conditions": []
    },
    "shortlisted_products": [
      {
        "product_name": "",
        "product_fit_score": 0,
        "evidence_strength_score": 0,
        "structurability_score": 0,
        "notes": []
      }
    ]
  }
}
```

If a field cannot be determined responsibly, use `null` or an empty list and explain why in the narrative.

## Quality bar
Before finalizing, check:
- entrepreneur and partner outputs must not contradict each other
- scores must align with cta status
- missing evidence must appear both in the narrative and the json
- product mix must only be proposed when it is materially better than a single-product structure
- entrepreneur language must be plain, concrete, and action-oriented
